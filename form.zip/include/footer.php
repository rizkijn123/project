	<div class="footer-wrap bg-white pd-20 mb-20 border-radius-5 box-shadow">
		VIP BloodLust - Redesign Template By <a href="#">Rizki Jaelani N & Restu Fauzi</a>
	</div>