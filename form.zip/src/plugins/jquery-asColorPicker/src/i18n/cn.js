import AsColorPicker from '../asColorPicker';

// Chinese (cn) localization
AsColorPicker.setLocalization('cn', {
  cancelText: "取消",
  applyText: "应用"
});
