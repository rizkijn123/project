import AsColorPicker from '../asColorPicker';

// Japanese (ja) localization
AsColorPicker.setLocalization('ja', {
  cancelText: "中止",
  applyText: "選択"
});
