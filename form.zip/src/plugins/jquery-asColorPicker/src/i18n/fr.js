import AsColorPicker from '../asColorPicker';

// French (fr) localization
AsColorPicker.setLocalization('fr', {
  cancelText: "Annuler",
  applyText: "Valider"
});
