import AsColorPicker from '../asColorPicker';

// Spanish (es) localization
AsColorPicker.setLocalization('es', {
  cancelText: "Cancelar",
  applyText: "Elegir"
});
