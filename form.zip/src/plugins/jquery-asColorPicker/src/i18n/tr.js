import AsColorPicker from '../asColorPicker';

// Turkish (tr) localization
AsColorPicker.setLocalization('tr', {
  cancelText: "Avbryt",
  applyText: "Välj"
});
