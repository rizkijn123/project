<?php
                    <div class="card">
                        <div class="header">
                            <h2>History Order</h2>
*Harga Diskon Cheat Berlaku Sampai Tanggal 1 Juli<br>

                        </div>
                        <div class="body">
				<div class="panel-body">
                        <div class="body table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                                    <th>Durasi Cheat</th>
                                                    <th>Harga Cheat</th>
                                                    <th>Perpanjang Cheat</th>
                                                    <th>Harga Cheat</th>
 
                                                </tr>
                                            </thead>
                                            <tbody>

<tr>
 <td>"3"</td>
 <td>".$data[reseller]."</td>
 <td>".$data[email]."</td>
 <td>".$data[username]."</td>
 <td>".$data[expired]."</td>
 <td>".$data[status]."</td>
</tr>";
}
?>
                                            </tbody>
                                        </table>
                                    </div>
                                   </div>
                                   </div>
                                   </div>
